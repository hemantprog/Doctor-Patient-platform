package com.healthcare.controller;

import com.healthcare.model.Doctor;
import com.healthcare.model.Patient;
import com.healthcare.service.HealthService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api")
public class HealthController {

    @Autowired
    private HealthService service;

    @PostMapping("/doctors")
    public ResponseEntity<Doctor> addDoctor(@Valid @RequestBody Doctor doctor) {
        return ResponseEntity.ok(service.saveDoctor(doctor));
    }

    @DeleteMapping("/doctors/{id}")
    public ResponseEntity<Void> deleteDoctor(@PathVariable Long id) {
        service.deleteDoctor(id);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/patients")
    public ResponseEntity<Patient> addPatient(@Valid @RequestBody Patient patient) {
        return ResponseEntity.ok(service.savePatient(patient));
    }

    @DeleteMapping("/patients/{id}")
    public ResponseEntity<Void> deletePatient(@PathVariable Long id) {
        service.deletePatient(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/suggest-doctor/{patientId}")
    public ResponseEntity<?> suggestDoctor(@PathVariable Long patientId) {
        try {
            return ResponseEntity.ok(service.suggestDoctors(patientId));
        } catch (IllegalStateException | IllegalArgumentException | NoSuchElementException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }
}