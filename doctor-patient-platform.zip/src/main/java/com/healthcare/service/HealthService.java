package com.healthcare.service;

import com.healthcare.model.Doctor;
import com.healthcare.model.Patient;
import com.healthcare.repository.DoctorRepository;
import com.healthcare.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class HealthService {

    @Autowired
    private DoctorRepository doctorRepo;

    @Autowired
    private PatientRepository patientRepo;

    private static final Map<String, String> symptomToSpeciality = Map.of(
        "Arthritis", "Orthopaedic",
        "Back Pain", "Orthopaedic",
        "Tissue injuries", "Orthopaedic",
        "Dysmenorrhea", "Gynecology",
        "Skin infection", "Dermatology",
        "Skin burn", "Dermatology",
        "Ear pain", "ENT"
    );

    public List<Doctor> suggestDoctors(Long patientId) {
        Patient patient = patientRepo.findById(patientId).orElse(null);
        if (patient == null) throw new NoSuchElementException("Patient not found");

        String city = patient.getCity();
        if (!List.of("Delhi", "Noida", "Faridabad").contains(city)) {
            throw new IllegalStateException("We are still waiting to expand to your location");
        }

        String symptom = patient.getSymptom();
        String speciality = symptomToSpeciality.get(symptom);

        List<Doctor> doctors = doctorRepo.findByCityAndSpeciality(city, speciality);
        if (doctors.isEmpty()) {
            throw new IllegalArgumentException("There isn’t any doctor present at your location for your symptom");
        }

        return doctors;
    }

    public Doctor saveDoctor(Doctor doctor) {
        return doctorRepo.save(doctor);
    }

    public void deleteDoctor(Long id) {
        doctorRepo.deleteById(id);
    }

    public Patient savePatient(Patient patient) {
        return patientRepo.save(patient);
    }

    public void deletePatient(Long id) {
        patientRepo.deleteById(id);
    }
}