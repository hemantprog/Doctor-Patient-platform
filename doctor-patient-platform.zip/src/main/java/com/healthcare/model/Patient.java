package com.healthcare.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class Patient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Size(min = 3)
    private String name;

    @Size(max = 20)
    private String city;

    @Email
    private String email;

    @Size(min = 10)
    private String phoneNumber;

    @Pattern(regexp = "Arthritis|Back Pain|Tissue injuries|Dysmenorrhea|Skin infection|Skin burn|Ear pain", message = "Invalid symptom")
    private String symptom;

    // Getters and Setters
}