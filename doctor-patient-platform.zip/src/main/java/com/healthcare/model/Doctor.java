package com.healthcare.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class Doctor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Size(min = 3)
    private String name;

    @Pattern(regexp = "Delhi|Noida|Faridabad", message = "City must be Delhi, Noida or Faridabad")
    private String city;

    @Email
    private String email;

    @Size(min = 10)
    private String phoneNumber;

    @Pattern(regexp = "Orthopaedic|Gynecology|Dermatology|ENT", message = "Invalid speciality")
    private String speciality;

    // Getters and Setters
}