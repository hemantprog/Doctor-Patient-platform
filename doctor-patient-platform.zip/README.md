# Doctor Suggestion Backend API

## Features
- Add/Delete Doctor
- Add/Delete Patient
- Suggest Doctors based on symptom and city

## Tech Stack
- Java 17
- Spring Boot 3
- Spring Data JPA (Hibernate)
- H2 Database
- Swagger (API Docs)

## How to Run
1. Import as Maven Project in IDE
2. Run DoctorPatientPlatformApplication.java
3. Access APIs via Swagger: http://localhost:8080/swagger-ui/index.html

## Postman
Postman collection is inside the postman folder.
